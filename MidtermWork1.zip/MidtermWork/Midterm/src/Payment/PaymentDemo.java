package Payment;

import java.util.Scanner;

public class PaymentDemo {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter payment method (Kaspi Bank || PayPal || Crypto): ");
        String methodType = scanner.nextLine();

        PaymentMethod paymentMethod = PaymentFactory.getPaymentMethod(methodType);
        paymentMethod = new PaymentAdapter(paymentMethod);
        System.out.print("Enter amount: ");
        double amount = scanner.nextDouble();
        scanner.nextLine();

        System.out.print("Enter details (Card Number || PayPal Email || Crypto Wallet): ");
        String details = scanner.nextLine();

        System.out.println("Are you sure? Enter '1234' to confirm payment.");
        String confirmationCode = scanner.nextLine();

        if (confirmationCode.equals("1234")) {
            boolean success = paymentMethod.processPayment(amount, details);
            if (success) {
                TransactionLogger.logTransaction("COMPLETED");
            } else {
                TransactionLogger.logTransaction("FAILED");
            }
        } else {
            System.out.println("Payment canceled.");
            TransactionLogger.logTransaction("CANCELED");
        }

        TransactionLogger.showTransactionHistory();
        scanner.close();
    }
}
