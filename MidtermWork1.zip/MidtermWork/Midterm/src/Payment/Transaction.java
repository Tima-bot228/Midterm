package Payment;

import java.util.UUID;

public class Transaction {
    private String id;
    private String status;

    public Transaction(String status) {
        this.id = UUID.randomUUID().toString();
        this.status = status;
    }

    public String getId() {
        return id;
    }

    public String getStatus() {
        return status;
    }
}
