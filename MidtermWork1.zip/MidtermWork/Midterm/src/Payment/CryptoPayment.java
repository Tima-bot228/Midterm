package Payment;

public class CryptoPayment implements PaymentMethod {
    @Override
    public boolean processPayment(double amount, String walletAddress) {
        if (walletAddress.length() < 10) {
            System.out.println("Invalid crypto wallet address.");
            return false;
        }
        System.out.println("Processing cryptocurrency payment: " + amount + "₸");
        return true;
    }
}
