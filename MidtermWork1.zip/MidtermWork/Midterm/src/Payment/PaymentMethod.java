package Payment;

public interface PaymentMethod {
    boolean processPayment(double amount, String accountDetails);
}
