package Payment;

public class PaymentFactory {
    public static PaymentMethod getPaymentMethod(String type) {
        switch (type.toLowerCase()) {
            case "kaspi":
            case "k":
                return new KaspiBank();
            case "paypal":
            case "p":
                return new PayPalPayment();
            case "crypto":
            case "c":
                return new CryptoPayment();
            default:
                throw new IllegalArgumentException("Invalid payment method: " + type);
        }
    }
}

