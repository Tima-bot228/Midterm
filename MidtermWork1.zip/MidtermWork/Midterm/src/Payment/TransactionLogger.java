package Payment;

import java.util.ArrayList;
import java.util.List;

public class TransactionLogger {
    private static List<Transaction> transactions = new ArrayList<>();

    public static void logTransaction(String status) {
        Transaction transaction = new Transaction(status);
        transactions.add(transaction);
        System.out.println("Transaction " + transaction.getId() + " - " + status);
    }

    public static void showTransactionHistory() {
        System.out.println("\n Transaction History:");
        for (Transaction t : transactions) {
            System.out.println(" " + t.getId() + " - " + t.getStatus());
        }
    }
}
