package Payment;

public class KaspiBank implements PaymentMethod {
    @Override
    public boolean processPayment(double amount, String cardNumber) {
        if (cardNumber.length() != 16) {
            System.out.println("Invalid credit card number.");
            return false;
        }
        System.out.println("Processing Kaspi Bank payment: " + amount + "₸");
        return true;
    }
}
