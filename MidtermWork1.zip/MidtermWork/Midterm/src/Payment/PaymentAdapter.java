package Payment;

public class PaymentAdapter implements PaymentMethod {
    private PaymentMethod paymentMethod;
    private PaymentValidator validator;

    public PaymentAdapter(PaymentMethod paymentMethod) {
        this.paymentMethod = paymentMethod;
        this.validator = new PaymentValidator();
    }

    @Override
    public boolean processPayment(double amount, String details) {
        if (!validator.validatePayment(amount)) {
            System.out.println("Payment rejected: Amount exceeds limit.");
            return false;
        }
        return paymentMethod.processPayment(amount, details);
    }
}
