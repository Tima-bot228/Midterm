package Payment;

public class PayPalPayment implements PaymentMethod {
    @Override
    public boolean processPayment(double amount, String email) {
        if (!email.contains("@")) {
            System.out.println("Invalid PayPal email.");
            return false;
        }
        System.out.println("Processing PayPal " + " payment: " + amount + "₸`");
        return true;
    }
}