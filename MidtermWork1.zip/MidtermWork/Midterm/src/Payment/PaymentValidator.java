package Payment;

public class PaymentValidator {
    public boolean validatePayment(double amount) {
        return amount <= 1000000;
    }
}
