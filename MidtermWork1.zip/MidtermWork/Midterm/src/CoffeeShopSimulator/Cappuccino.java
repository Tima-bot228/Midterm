package CoffeeShopSimulator;

public class Cappuccino implements Coffee {
    @Override
    public double getCost() {
        return 550;
    }

    @Override
    public String getDescription() {
        return "Cappuccino";
    }
}
