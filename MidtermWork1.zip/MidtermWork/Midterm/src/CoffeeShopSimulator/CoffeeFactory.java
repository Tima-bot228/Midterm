package CoffeeShopSimulator;

public class CoffeeFactory {
    public static Coffee getCoffee(String type) {
        switch (type.toLowerCase()) {
            case "espresso":
            case "e":
                return new Espresso();
            case "cappuccino":
            case "c":
                return new Cappuccino();
            default:
                throw new IllegalArgumentException("Invalid coffee type: " + type);
        }
    }
}
