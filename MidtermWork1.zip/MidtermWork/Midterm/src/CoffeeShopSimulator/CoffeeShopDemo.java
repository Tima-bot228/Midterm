package CoffeeShopSimulator;

import java.util.Scanner;

public class CoffeeShopDemo {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Choose coffee (Espresso / Cappuccino): ");
        String coffeeType = scanner.nextLine();

        Coffee coffee = CoffeeFactory.getCoffee(coffeeType);

        System.out.print("Add milk? (yes/no): ");
        if (scanner.nextLine().equalsIgnoreCase("yes")) {
            coffee = new MilkDecorator(coffee);
        }

        System.out.print("Add caramel? (yes/no): ");
        if (scanner.nextLine().equalsIgnoreCase("yes")) {
            coffee = new CaramelDecorator(coffee);
        }

        System.out.println("Your order: " + coffee.getDescription());
        System.out.println("Total cost: " + coffee.getCost() + "₸" );
        System.out.println("Total cost: " + coffee.getCost()/5 + "₽");
        System.out.println("Total cost: " + coffee.getCost()/500 + "$" );

        scanner.close();
    }
}
