package CoffeeShopSimulator;

public class Espresso implements Coffee {
    @Override
    public double getCost() {
        return 400;
    }

    @Override
    public String getDescription() {
        return "Espresso";
    }
}
