package CoffeeShopSimulator;

public class CaramelDecorator extends CoffeeDecorator {
    public CaramelDecorator(Coffee coffee) {
        super(coffee);
    }

    @Override
    public double getCost() {
        return super.getCost() + 150;
    }

    @Override
    public String getDescription() {
        return super.getDescription() + " and with Caramel";
    }
}
